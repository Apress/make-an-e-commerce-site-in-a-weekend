<?php
include('topmenu.php');
?>
<span id="crossfade">
	<a href="itemlist.php?category=CellPhone">
 	<img class="bottom" src="images/AppleiPhone4s.jpg" style="max-width:350px;max-height:350px;width:auto;height:auto;" />
	<img  class="top" src="images/MicromaxKnight2E471.jpg" style="max-width:350px;max-height:350px;width:auto;height:auto;" /></a>
</span>
<span id="crossfade">
	<a href="itemlist.php?category=CellPhone">
 	<img class="bottom" src="images/MicrosoftLumia640XL.jpg" style="max-width:350px;max-height:350px;width:auto;height:auto;" />
	<img  class="top" src="images/XperiaT3White.jpg" style="max-width:350px;max-height:350px;width:auto;height:auto;" /></a>
</span>
<span id="crossfade">
	<a href="itemlist.php?category=Laptop">
 	<img class="bottom" src="images/DellVostro153558.jpg" style="max-width:350px;max-height:350px;width:auto;height:auto;" />
	<img  class="top" src="images/HPProbook6570.jpg" style="max-width:350px;max-height:350px;width:auto;height:auto;" /></a>
</span>
</body>
</html>

