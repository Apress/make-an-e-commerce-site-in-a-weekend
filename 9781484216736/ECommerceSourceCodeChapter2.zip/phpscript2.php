<html>
	<body>
		<?php
			$name="John";
			echo "Welcome $name <br/>";
			$a=10;
			$b=20;
			echo "Sum of $a and $b is "; 
			echo $a+$b;
		?>
	</body>
</html>
