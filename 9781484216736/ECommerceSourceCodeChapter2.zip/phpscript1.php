<html>
	<head>
	</head>
	<body>
		<h1>Bintu Online Bazar</h1>
		<?php
			echo '<b>Welcome to our store</b>';
		?>
	</body>
</html>
