<html>
	<body>
		<?php
			$a="John";
			echo "Hello $a!" . " Welcome to our store";
		?>
	</body>
</html>
