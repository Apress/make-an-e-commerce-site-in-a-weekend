<?php
phpinfo();
?> 
